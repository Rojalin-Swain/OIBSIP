package com.nms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NumberGuessingGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
