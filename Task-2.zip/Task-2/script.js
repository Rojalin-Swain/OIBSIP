var typed =  new Typed('#typed',{
    stringsElement: '#typed-strings',
    loop: true,
    typeSpeed:120,
    backSpeed:50
})
// const about=document.querySelector("#about")
const about=document.querySelector("#about")
const aboutLeft = document.querySelector("#aboutLeft")

const aboutRight = document.querySelector("#aboutRight")
const home = document.querySelector("#home")



const srTop = ScrollReveal({
    origin: 'top',
    distance: '80px',
    duration: 3000,
    reset: true
})
const srLeft = ScrollReveal({
    origin: 'left',
    distance: '-30px',
    duration: 3000,
    reset: true
})
const srRight = ScrollReveal({
    origin: 'right',
    distance: '-30px',
    duration: 3000,
    reset: true
})

srTop.reveal(about,{delay: 100})
srLeft.reveal(aboutLeft,{delay: 100})
srRight.reveal(aboutRight,{delay: 100})
// srRight.reveal(home,{delay: 100})
srTop.reveal(home,{delay: 100})