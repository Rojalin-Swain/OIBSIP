package com.org;

import java.util.ArrayList;
import java.util.List;

public class Account {

		 private String userId;
		 private String pin;
		 private double balance;
		 private List<Transaction> transactionHistory;
		 
		 public Account(String userId, String pin, double initialBalance) {
		        this.userId = userId;
		        this.pin = pin;
		        this.balance = initialBalance;
		        this.transactionHistory = new ArrayList<>();
		    }

		public String getUserId() {
			return userId;
		}

		public String getPin() {
			return pin;
		}

		public double getBalance() {
			return balance;
		}

		 public void deposit(double amount) {
		        balance += amount;
		        transactionHistory.add(new Transaction("Deposit", amount));
		    }
		 public boolean withdraw(double amount) {
		     if (balance >= amount) {
		         balance -= amount;
		         transactionHistory.add(new Transaction("Withdraw", amount));
		         return true;
		     } else {
		         return false;
		     }
		 }
		 public void transfer(Account toAccount, double amount) {
		     if (withdraw(amount)) {
		         toAccount.deposit(amount);
		         transactionHistory.add(new Transaction("Transfer to " + toAccount.getUserId(), amount));
		     }
		}
		 
		 public List<Transaction> getTransactionHistory() {
				return transactionHistory;
			}

		

}
