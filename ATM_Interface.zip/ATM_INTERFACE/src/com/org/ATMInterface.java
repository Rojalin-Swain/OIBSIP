package com.org;

import java.util.Scanner;

public class ATMInterface {

	 private Account account;
	 private static Scanner scanner = new Scanner(System.in);

	 public ATMInterface(Account account) {
        this.account = account;
	 }
	 
	 public boolean showMenu() {
	        boolean quit = false;
	        while (!quit) {
	            System.out.println("\nATM Menu:");
	            System.out.println("1. Transactions History");
	            System.out.println("2. Withdraw");
	            System.out.println("3. Deposit");
	            System.out.println("4. Transfer");
	            System.out.println("5. Quit");
	            System.out.print("Choose an option: ");
	            int choice = scanner.nextInt();
	            scanner.nextLine(); // consume newline
	            
	            switch (choice) {
	                case 1:
	                    showTransactionHistory();
	                    break;
	                case 2:
	                    withdraw();
	                    break;
	                case 3:
	                    deposit();
	                    break;
	                case 4:
	                    transfer();
	                    break;
	                case 5:
	                    quit = true;
	                    System.out.println("Thank you for using the ATM. Goodbye!");
	                    break;
	                default:
	                    System.out.println("Invalid option. Please try again.");
	            }
	        }
	        return quit;
	    }
	 private void showTransactionHistory() {
	        System.out.println("\nTransaction History:");
	        for (Transaction transaction : account.getTransactionHistory()) {
	            System.out.println(transaction);
	        }
	 }
	 private void withdraw() {
	        System.out.print("Enter amount to withdraw: ");
	        double amount = scanner.nextDouble();
	        scanner.nextLine(); // consume newline
	        if (account.withdraw(amount)) {
	            System.out.println("Withdrawal successful. New balance: " + account.getBalance());
	        } else {
	            System.out.println("Insufficient balance.");
	        }
	  }
	 private void deposit() {
	        System.out.print("Enter amount to deposit: ");
	        double amount = scanner.nextDouble();
	        scanner.nextLine(); // consume newline
	        account.deposit(amount);
	        System.out.println("Deposit successful. New balance: " + account.getBalance());
	 }
	 private void transfer() {
	        System.out.print("Enter recipient user ID: ");
	        String recipientId = scanner.nextLine();
	        System.out.print("Enter amount to transfer: ");
	        double amount = scanner.nextDouble();
	        scanner.nextLine(); // consume newline
	        
	        Bank bank = new Bank();
	        Account recipient = bank.getAccount(recipientId);
	        if (recipient != null) {
	            account.transfer(recipient, amount);
	            System.out.println("Transfer successful. New balance: " + account.getBalance());
	        } else {
	            System.out.println("Recipient account not found.");
	        }
	    }

}
