package com.org;

import java.util.Scanner;

public class ATM {
	
	private static Scanner scanner = new Scanner(System.in);
    private static Bank bank = new Bank();

	public static void main(String[] args) {
		 System.out.println("Welcome to the ATM");
	        boolean exit = false;
	        
	        while (!exit) {
	            System.out.print("Enter User ID: ");
	            String userId = scanner.nextLine();
	            System.out.print("Enter PIN: ");
	            String pin = scanner.nextLine();
	            
	            Account account = bank.authenticateUser(userId, pin);
	            if (account != null) {
	                ATMInterface atmInterface = new ATMInterface(account);
	                exit = atmInterface.showMenu();
	            } else {
	                System.out.println("Invalid credentials. Please try again.");
	            }
	        } 
	}

}
